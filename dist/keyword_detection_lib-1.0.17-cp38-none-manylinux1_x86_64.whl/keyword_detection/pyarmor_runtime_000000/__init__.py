# Pyarmor 9.0.5 (trial), 000000, 2024-11-16T00:07:08.281342
from .pyarmor_runtime import __pyarmor__
