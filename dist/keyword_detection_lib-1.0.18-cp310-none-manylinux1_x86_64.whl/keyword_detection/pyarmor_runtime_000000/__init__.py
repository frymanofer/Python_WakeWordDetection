# Pyarmor 9.0.6 (trial), 000000, 2024-12-09T15:10:13.772982
from .pyarmor_runtime import __pyarmor__
