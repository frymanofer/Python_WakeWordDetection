# Pyarmor 9.0.6 (trial), 000000, 2024-12-06T15:56:07.548130
from .pyarmor_runtime import __pyarmor__
