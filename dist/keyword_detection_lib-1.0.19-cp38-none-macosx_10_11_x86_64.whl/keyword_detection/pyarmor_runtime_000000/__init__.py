# Pyarmor 9.0.6 (trial), 000000, 2024-12-18T10:25:24.500192
from .pyarmor_runtime import __pyarmor__
