# Pyarmor 9.0.6 (trial), 000000, 2024-12-06T15:46:00.080538
from .pyarmor_runtime import __pyarmor__
