# Pyarmor 9.0.6 (trial), 000000, 2024-12-06T15:53:37.122009
from .pyarmor_runtime import __pyarmor__
