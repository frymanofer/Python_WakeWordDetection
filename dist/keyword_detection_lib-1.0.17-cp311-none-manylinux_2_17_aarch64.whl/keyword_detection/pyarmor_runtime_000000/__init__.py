# Pyarmor 9.0.5 (trial), 000000, 2024-11-16T00:12:40.124435
from .pyarmor_runtime import __pyarmor__
