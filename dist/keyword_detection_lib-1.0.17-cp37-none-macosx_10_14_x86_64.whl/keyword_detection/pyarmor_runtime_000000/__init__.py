# Pyarmor 9.0.6 (trial), 000000, 2024-12-08T20:13:42.148286
from .pyarmor_runtime import __pyarmor__
