# Pyarmor 9.0.6 (trial), 000000, 2024-12-19T18:34:00.194897
from .pyarmor_runtime import __pyarmor__
