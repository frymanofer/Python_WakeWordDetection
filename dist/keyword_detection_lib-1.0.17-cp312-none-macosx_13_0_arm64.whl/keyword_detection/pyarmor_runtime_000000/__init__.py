# Pyarmor 9.0.6 (trial), 000000, 2024-12-06T15:12:08.713047
from .pyarmor_runtime import __pyarmor__
