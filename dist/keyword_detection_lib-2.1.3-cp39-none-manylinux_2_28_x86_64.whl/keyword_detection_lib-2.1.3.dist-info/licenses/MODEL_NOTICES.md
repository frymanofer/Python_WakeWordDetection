See the repository-level MODEL_NOTICES.md for the model and native asset terms.
