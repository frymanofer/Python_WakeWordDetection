# Pyarmor 9.0.6 (trial), 000000, 2024-12-06T15:52:28.432986
from .pyarmor_runtime import __pyarmor__
