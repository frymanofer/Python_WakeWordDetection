# Pyarmor 9.0.6 (trial), 000000, 2024-12-09T15:11:51.460011
from .pyarmor_runtime import __pyarmor__
