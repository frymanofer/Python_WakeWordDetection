# Pyarmor 9.0.5 (trial), 000000, 2024-11-16T00:06:17.092848
from .pyarmor_runtime import __pyarmor__
