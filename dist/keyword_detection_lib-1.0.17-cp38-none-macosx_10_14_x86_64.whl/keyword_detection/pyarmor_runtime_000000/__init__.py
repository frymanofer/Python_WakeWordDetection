# Pyarmor 9.0.6 (trial), 000000, 2024-12-08T19:52:01.046600
from .pyarmor_runtime import __pyarmor__
