# Pyarmor 9.0.6 (trial), 000000, 2024-12-19T18:29:41.201184
from .pyarmor_runtime import __pyarmor__
