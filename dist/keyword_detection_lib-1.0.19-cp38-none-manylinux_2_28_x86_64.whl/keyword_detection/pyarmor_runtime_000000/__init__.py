# Pyarmor 9.0.6 (trial), 000000, 2024-12-19T18:27:38.405604
from .pyarmor_runtime import __pyarmor__
