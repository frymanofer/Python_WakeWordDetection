# Pyarmor 9.0.6 (trial), 000000, 2024-12-09T14:45:23.196444
from .pyarmor_runtime import __pyarmor__
